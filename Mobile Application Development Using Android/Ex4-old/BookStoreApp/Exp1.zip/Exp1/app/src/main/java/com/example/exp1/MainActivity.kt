package com.example.exp1

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.exp1.R

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val editTextHeight = findViewById<EditText>(R.id.editTextHeight)
        val editTextWeight = findViewById<EditText>(R.id.editTextWeight)
        val buttonCalculate = findViewById<Button>(R.id.buttonCalculate)
        val textViewResult = findViewById<TextView>(R.id.textViewResult)

        buttonCalculate.setOnClickListener {
            val heightStr = editTextHeight.text.toString()
            val weightStr = editTextWeight.text.toString()

            if (heightStr.isNotEmpty() && weightStr.isNotEmpty()) {
                val height = heightStr.toFloat()  // Height is in meters
                val weight = weightStr.toFloat()
                val bmi = weight / (height * height)

                val status = when {
                    bmi < 18 -> "Underweight"
                    bmi in 18.0..24.9 -> "Normal"
                    bmi in 25.0..29.9 -> "Overweight"
                    else -> "Obese"
                }

                val bmiResult = String.format("Your BMI is: %.2f\nStatus: %s", bmi, status)
                textViewResult.text = bmiResult
                Toast.makeText(this, "Status : "+bmiResult, Toast.LENGTH_SHORT).show()
            } else {
                textViewResult.text = "Please enter valid height and weight"
            }
        }
    }
}